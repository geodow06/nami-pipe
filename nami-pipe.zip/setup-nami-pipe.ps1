
# Set environment variable
$ENV:CARDANO_NODE_SOCKET_PATH = (Get-ChildItem \\.\pipe\ | Where-Object {$_.name -like "cardano-node*"}).FullName

# Run the submit api
.\cardano-node-1.33.0-win64\cardano-submit-api.exe --mainnet --socket-path $ENV:CARDANO_NODE_SOCKET_PATH --config .\cardano-node-1.33.0-win64\tx-submit-mainnet-config.yaml --port 8090